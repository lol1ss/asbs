#!/usr/bin/env python3
# Мінімальний аналог `yara [-s] rules.yar file...` на базі yara-python
import sys, yara
args=[a for a in sys.argv[1:]]
show=False
if args and args[0]=='-s': show=True; args=args[1:]
rules=yara.compile(args[0])
for f in args[1:]:
    for m in rules.match(f):
        print(m.rule, f)
        if show:
            for s in m.strings:
                for i in s.instances:
                    print(f"0x{i.offset:x}:{s.identifier}: {i.matched_data[:40]}")
