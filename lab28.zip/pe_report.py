import sys, math, pefile, datetime, hashlib
f=sys.argv[1]
mode=sys.argv[2]
pe=pefile.PE(f)
def ent(b):
    if not b: return 0.0
    from collections import Counter
    c=Counter(b); n=len(b)
    return -sum(v/n*math.log2(v/n) for v in c.values())
if mode=='header':
    print(f"File: {f}")
    print(f"DOS e_magic      : {hex(pe.DOS_HEADER.e_magic)} ('MZ')")
    print(f"e_lfanew (PE off): {hex(pe.DOS_HEADER.e_lfanew)}")
    print(f"Signature        : {hex(pe.NT_HEADERS.Signature)} ('PE\\0\\0')")
    fh=pe.FILE_HEADER
    print(f"Machine          : {hex(fh.Machine)} ({pefile.MACHINE_TYPE.get(fh.Machine)})")
    print(f"NumberOfSections : {fh.NumberOfSections}")
    print(f"TimeDateStamp    : {hex(fh.TimeDateStamp)} -> {datetime.datetime.fromtimestamp(fh.TimeDateStamp, datetime.UTC)} UTC")
    print(f"Characteristics  : {hex(fh.Characteristics)}  {[n for n,v in pefile.IMAGE_CHARACTERISTICS.items() if isinstance(v,int) and fh.Characteristics & v] if hasattr(pefile,'IMAGE_CHARACTERISTICS') else ''}")
    oh=pe.OPTIONAL_HEADER
    print(f"Magic            : {hex(oh.Magic)} (PE32+)" if oh.Magic==0x20b else f"Magic: {hex(oh.Magic)} (PE32)")
    print(f"AddressOfEntryPnt: {hex(oh.AddressOfEntryPoint)}")
    print(f"ImageBase        : {hex(oh.ImageBase)}")
    print(f"SizeOfImage      : {hex(oh.SizeOfImage)}")
    print(f"Subsystem        : {oh.Subsystem} ({pefile.SUBSYSTEM_TYPE.get(oh.Subsystem)})")
    print(f"DllCharacteristics: {hex(oh.DllCharacteristics)}")
    print(f"Imphash          : {pe.get_imphash()}")
elif mode=='sections':
    print(f"{'Name':8} {'VirtAddr':>9} {'VirtSize':>9} {'RawSize':>9} {'Entropy':>8}  Flags")
    ep=pe.OPTIONAL_HEADER.AddressOfEntryPoint
    for s in pe.sections:
        n=s.Name.rstrip(b'\0').decode(errors='replace')
        fl=s.Characteristics
        flags=('R' if fl&0x40000000 else '-')+('W' if fl&0x80000000 else '-')+('X' if fl&0x20000000 else '-')
        mark='  <== EntryPoint' if s.VirtualAddress<=ep<s.VirtualAddress+max(s.Misc_VirtualSize,s.SizeOfRawData) else ''
        print(f"{n:8} {hex(s.VirtualAddress):>9} {hex(s.Misc_VirtualSize):>9} {hex(s.SizeOfRawData):>9} {abs(ent(s.get_data())):8.2f}  {flags}{mark}")
elif mode=='imports':
    cnt=0
    for e in getattr(pe,'DIRECTORY_ENTRY_IMPORT',[]):
        names=[i.name.decode() for i in e.imports if i.name]
        cnt+=len(names)
        print(f"[{e.dll.decode()}]  ({len(names)})")
        for n in names: print("    ",n)
    print(f"\nУсього імпортованих функцій: {cnt}")
