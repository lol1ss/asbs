import "pe"
import "math"

rule LAB128_PE_Executable_Any_Extension
{
    meta:
        description = "PE-файл за сигнатурою MZ/PE незалежно від розширення"
        author      = "Курсант, лаб. робота 1/28"
    condition:
        uint16(0) == 0x5A4D and
        uint32(uint32(0x3C)) == 0x00004550
}

rule LAB128_UPX_Packed
{
    meta:
        description = "Файл упаковано UPX (імена секцій, висока ентропія)"
    condition:
        uint16(0) == 0x5A4D and
        (
            for any s in pe.sections : (s.name == "UPX0" or s.name == "UPX1")
        ) and
        for any s in pe.sections :
            ( math.entropy(s.raw_data_offset, s.raw_data_size) > 7.0 )
}

rule LAB128_Training_Sample_Plain
{
    meta:
        description = "Навчальний зразок: індикатори у відкритому вигляді + підозрілі імпорти"
    strings:
        $c2     = "update-service.example.invalid" ascii
        $runkey = "CurrentVersion\\Run" ascii
        $mutex  = "LAB128_TRAINING_MUTEX" ascii
        $ua     = "LabSample/1.28" ascii
        $mark   = "LAB128-TRAINING-SAMPLE" ascii
    condition:
        uint16(0) == 0x5A4D and 3 of them and
        pe.imports("kernel32.dll", "VirtualAlloc") and
        pe.imports("kernel32.dll", "WriteProcessMemory") and
        pe.imports("kernel32.dll", "CreateRemoteThread") and
        pe.imports("wininet.dll", "InternetOpenA")
}

rule LAB128_Training_Sample_XOR_String
{
    meta:
        description = "Рядок, схований однобайтовим XOR (ключ 0x5A)"
    strings:
        $x = "decoded: training" ascii xor(0x01-0xff)
    condition:
        uint16(0) == 0x5A4D and $x
}
