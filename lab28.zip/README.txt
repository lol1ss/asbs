Матеріали до практичної роботи 1/28 (Windows; тільки для ізольованої ВМ!)
Розпакуйте у C:\lab128 ; зразки покладіть у C:\lab128\samples
sample_plain.exe  - навчальний НЕШКІДЛИВИЙ зразок (не запускати на робочій машині)
sample_packed.exe - той самий зразок, упакований UPX
invoice_2026.pdf  : copy .\sample_packed.exe .\invoice_2026.pdf
Python: py -m pip install pefile yara-python
rules.yar - YARA-правила ; pe_report.py <файл> header|sections|imports ; entropy.py <файли>
Потрібні також: Sysinternals Strings (strings64.exe), YARA для Windows (yara64.exe), UPX (upx.exe)
Якщо Windows Defender видалить зразок - додайте C:\lab128 у виключення.
