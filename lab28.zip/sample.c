/* Навчальний НЕШКІДЛИВИЙ зразок для лабораторної роботи 1/28.
   Нічого не завантажує, не змінює реєстр і не запускає процесів:
   лише містить типові "індикатори" (рядки, імпорти) для статичного аналізу. */
#include <windows.h>
#include <wininet.h>
#include <stdio.h>

/* "Індикатори" у відкритому вигляді */
const char *c2_url    = "http://update-service.example.invalid/gate.php";
const char *run_key   = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
const char *mutex_nm  = "Global\\LAB128_TRAINING_MUTEX";
const char *ua        = "Mozilla/5.0 (LabSample/1.28)";
const char *marker    = "LAB128-TRAINING-SAMPLE-NOT-MALWARE";

/* Обфускований рядок: XOR з ключем 0x5A */
static unsigned char enc[] = {0x12,0x3f,0x36,0x36,0x35,0x7a,0x3e,0x3f,0x39,0x35,0x3e,0x3f,0x3e,0x60,0x7a,0x2e,0x28,0x3b,0x33,0x34,0x33,0x34,0x3d,0x7a,0x29,0x3b,0x37,0x2a,0x36,0x3f,0x5a};

typedef LPVOID (WINAPI *PVA)(LPVOID,SIZE_T,DWORD,DWORD);
typedef HINTERNET (WINAPI *PIO)(LPCSTR,DWORD,LPCSTR,LPCSTR,DWORD);
typedef LONG (WINAPI *PRSV)(HKEY,LPCSTR,DWORD,DWORD,const BYTE*,DWORD);

void *api_table[] = { (void*)VirtualAlloc, (void*)InternetOpenA, (void*)InternetOpenUrlA,
    (void*)RegSetValueExA, (void*)CreateRemoteThread, (void*)WriteProcessMemory, (void*)IsDebuggerPresent };

int main(int argc, char **argv) {
    /* Посилання на API без виклику - потрапляють у таблицю імпорту */
    printf("api table: %d\n", (int)(sizeof(api_table)/sizeof(api_table[0])));
    volatile unsigned char key = 0x5A;
    char buf[sizeof(enc)+1];
    for (size_t i = 0; i < sizeof(enc); i++) buf[i] = enc[i] ^ key;
    buf[sizeof(enc)-1] = 0;
    printf("%s\n", buf);
    printf("%s\n", marker);
    return argc > 99 ? (int)(c2_url[0]+run_key[0]+mutex_nm[0]+ua[0]) : 0;
}
