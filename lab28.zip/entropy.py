import sys, math, collections
for f in sys.argv[1:]:
    b=open(f,'rb').read(); c=collections.Counter(b)
    print(f"{f:28} size={len(b):6}  H={-sum(v/len(b)*math.log2(v/len(b)) for v in c.values()):.2f} біт/байт")
